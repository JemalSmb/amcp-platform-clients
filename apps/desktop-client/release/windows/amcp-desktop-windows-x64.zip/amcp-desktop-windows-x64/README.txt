AMCP desktop clients (Windows x64)

  amcp_user_desktop.exe     regular user client
  amcp_admin_desktop.exe    admin client

Keep the files in this folder together. Settings live in the ".env" file next to the programs
(API and Supabase URLs, public anon key). The programs are unsigned, so Windows SmartScreen may warn:
choose "More info" -> "Run anyway".
